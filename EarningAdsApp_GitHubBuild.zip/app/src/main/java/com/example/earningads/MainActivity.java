package com.example.earningads;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

public class MainActivity extends Activity {
    private int coins = 0;
    private TextView coinText, balanceText, status;
    private static final int COINS_PER_RUPEE = 100;
    private static final int MIN_WITHDRAW_COINS = 4000;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        coinText=findViewById(R.id.coins);
        balanceText=findViewById(R.id.balance);
        status=findViewById(R.id.status);
        Button watch=findViewById(R.id.watch);
        Button withdraw=findViewById(R.id.withdraw);

        watch.setOnClickListener(v -> {
            // Demo only. Real rewards must be granted only from a verified rewarded-ad completion callback.
            coins += 10;
            update();
            Toast.makeText(this, "+10 coins (demo)", Toast.LENGTH_SHORT).show();
        });

        withdraw.setOnClickListener(v -> {
            if (coins < MIN_WITHDRAW_COINS) {
                Toast.makeText(this, "Minimum withdrawal is ₹40 (4,000 coins)", Toast.LENGTH_LONG).show();
                return;
            }
            double rupees = coins / (double) COINS_PER_RUPEE;
            Toast.makeText(this, "Withdrawal request: ₹" + String.format("%.2f", rupees) + " (demo)", Toast.LENGTH_LONG).show();
        });
        update();
    }

    private void update() {
        coinText.setText("Coins: " + coins);
        balanceText.setText(String.format("Balance: ₹%.2f", coins / (double) COINS_PER_RUPEE));
        status.setText("Minimum withdrawal: ₹40 (4,000 coins)");
    }
}
