package com.example.earningads;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    int coins = 0;
    TextView coinText;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        coinText=findViewById(R.id.coins);
        Button watch=findViewById(R.id.watch);
        Button wallet=findViewById(R.id.wallet);
        watch.setOnClickListener(v -> {
            // Demo reward. Replace this callback with a verified rewarded-ad completion callback.
            coins += 10;
            coinText.setText("Coins: " + coins);
            Toast.makeText(this, "+10 coins (demo)", Toast.LENGTH_SHORT).show();
        });
        wallet.setOnClickListener(v -> Toast.makeText(this,
            "Wallet: " + coins + " coins\nWithdrawal module will be connected next.",
            Toast.LENGTH_LONG).show());
    }
}
